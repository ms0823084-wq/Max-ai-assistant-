package com.example.data.gemini

import android.graphics.Bitmap
import android.util.Base64
import com.example.data.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    /**
     * Tests API key validity and returns actual server response or real exception message.
     */
    suspend fun testConnection(apiKey: String): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Gemini API key is blank. Please enter your key."))
        }
        val startTime = System.currentTimeMillis()
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey"
            val bodyJson = JSONObject().apply {
                val contents = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().apply { put("text", "Hello, are you ready?") })
                        }
                        put("parts", parts)
                    }
                    put(contentObj)
                }
                put("contents", contents)
            }

            val request = Request.Builder()
                .url(url)
                .post(bodyJson.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val latency = System.currentTimeMillis() - startTime
                    Result.success("Connection Successful! Model responded in ${latency}ms")
                } else {
                    val errorMsg = try {
                        val json = JSONObject(responseBody)
                        json.optJSONObject("error")?.optString("message") ?: responseBody
                    } catch (e: Exception) {
                        responseBody
                    }
                    Result.failure(Exception("HTTP ${response.code}: $errorMsg"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Generates a context-aware warm conversational reply in Hindi/English/Hinglish.
     */
    suspend fun generateReply(
        prompt: String,
        history: List<ChatMessage>,
        systemInstruction: String,
        apiKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("No Gemini API key provided."))
        }
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey"
            val root = JSONObject()

            // System instruction
            val sysObj = JSONObject().apply {
                val parts = JSONArray().apply {
                    put(JSONObject().apply { put("text", systemInstruction) })
                }
                put("parts", parts)
            }
            root.put("systemInstruction", sysObj)

            // Conversation history (last 10 messages for context)
            val contentsArray = JSONArray()
            val recent = history.takeLast(10)
            for (msg in recent) {
                val role = if (msg.sender == "user") "user" else "model"
                val c = JSONObject().apply {
                    put("role", role)
                    val parts = JSONArray().apply {
                        put(JSONObject().apply { put("text", msg.text) })
                    }
                    put("parts", parts)
                }
                contentsArray.put(c)
            }

            // Current prompt
            contentsArray.put(JSONObject().apply {
                put("role", "user")
                val parts = JSONArray().apply {
                    put(JSONObject().apply { put("text", prompt) })
                }
                put("parts", parts)
            })

            root.put("contents", contentsArray)

            // Generation config
            val config = JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 500)
            }
            root.put("generationConfig", config)

            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val json = JSONObject(bodyStr)
                    val candidates = json.optJSONArray("candidates")
                    val candidate = candidates?.optJSONObject(0)
                    val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")
                    val text = parts?.optJSONObject(0)?.optString("text") ?: ""
                    Result.success(text.trim())
                } else {
                    Result.failure(Exception("Gemini error ${response.code}: $bodyStr"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Multimodal analysis of camera frame or uploaded image.
     */
    suspend fun analyzeImage(
        bitmap: Bitmap,
        prompt: String,
        apiKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("No Gemini API key provided."))
        }
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=$apiKey"
            val base64Data = bitmapToBase64(bitmap)

            val root = JSONObject()
            val contents = JSONArray()
            val contentObj = JSONObject().apply {
                val parts = JSONArray()
                // Image part
                val imagePart = JSONObject().apply {
                    val inlineData = JSONObject().apply {
                        put("mimeType", "image/jpeg")
                        put("data", base64Data)
                    }
                    put("inlineData", inlineData)
                }
                parts.put(imagePart)

                // Text prompt part
                val textPart = JSONObject().apply {
                    put("text", "$prompt\n\nProvide a clear, natural, and helpful spoken answer in Hindi and English (Hinglish). Focus on identifying objects, reading medicine labels, currency, or text precisely.")
                }
                parts.put(textPart)

                put("parts", parts)
            }
            contents.put(contentObj)
            root.put("contents", contents)

            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    val json = JSONObject(bodyStr)
                    val candidates = json.optJSONArray("candidates")
                    val candidate = candidates?.optJSONObject(0)
                    val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")
                    val text = parts?.optJSONObject(0)?.optString("text") ?: ""
                    Result.success(text.trim())
                } else {
                    Result.failure(Exception("Vision error ${response.code}: $bodyStr"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Screen understanding: sends screenshot to Gemini and provides a short spoken summary.
     */
    suspend fun understandScreen(
        screenshotBitmap: Bitmap,
        apiKey: String
    ): Result<String> {
        val prompt = "Look at this Android device screen. Explain in 2-3 short, spoken Hindi-English sentences what screen this is, what the user is looking at, and any prominent actions or alerts visible."
        return analyzeImage(screenshotBitmap, prompt, apiKey)
    }

    /**
     * Auto-reply drafting for WhatsApp bot.
     */
    suspend fun draftWhatsAppReply(
        sender: String,
        incomingMessage: String,
        tone: String,
        apiKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val prompt = "A WhatsApp message was received from '$sender': \"$incomingMessage\"\n" +
                "Draft a short, natural, and polite reply in the user's tone ($tone). " +
                "Do not include quotes or pleasantry meta-text. Just output the exact reply text."
        generateReply(
            prompt = prompt,
            history = emptyList(),
            systemInstruction = "You are an intelligent messaging assistant that drafts natural WhatsApp replies.",
            apiKey = apiKey
        )
    }

    /**
     * Summarizes chat history.
     */
    suspend fun summarizeChat(
        chatTranscript: String,
        apiKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val prompt = "Summarize this WhatsApp conversation briefly in 2 to 4 bullet points in clear Hinglish:\n\n$chatTranscript"
        generateReply(
            prompt = prompt,
            history = emptyList(),
            systemInstruction = "You are a concise conversation summarizer.",
            apiKey = apiKey
        )
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        // Resize down if too large to conserve bandwidth and speed up response
        val scaled = if (bitmap.width > 1024 || bitmap.height > 1024) {
            val scaleFactor = 1024f / Math.max(bitmap.width, bitmap.height)
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scaleFactor).toInt(),
                (bitmap.height * scaleFactor).toInt(),
                true
            )
        } else {
            bitmap
        }
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val byteArray = stream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }
}
