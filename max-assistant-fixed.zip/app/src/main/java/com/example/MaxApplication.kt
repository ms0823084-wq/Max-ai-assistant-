package com.example

import android.app.Application
import com.example.data.gemini.GeminiService
import com.example.data.local.AppDatabase
import com.example.data.local.SecurityManager
import com.example.service.AntiTheftController
import com.example.service.PhoneCommander
import com.example.speech.TtsManager

class MaxApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var securityManager: SecurityManager
        private set

    lateinit var geminiService: GeminiService
        private set

    lateinit var ttsManager: TtsManager
        private set

    lateinit var phoneCommander: PhoneCommander
        private set

    lateinit var antiTheftController: AntiTheftController
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getInstance(this)
        securityManager = SecurityManager(this)
        geminiService = GeminiService()
        ttsManager = TtsManager(this)
        phoneCommander = PhoneCommander(this)
        antiTheftController = AntiTheftController(this)

        // Apply voice parameters
        ttsManager.applySettings(
            gender = securityManager.voiceGender,
            speed = securityManager.voiceSpeed,
            pitch = securityManager.voicePitch
        )

        // If Anti-Theft was armed previously, restore sensor listener
        if (securityManager.isAntiTheftArmed) {
            antiTheftController.onArmStateChanged(true)
        }
    }

    override fun onTerminate() {
        super.onTerminate()
        ttsManager.shutdown()
    }

    companion object {
        lateinit var instance: MaxApplication
            private set
    }
}
