package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.example.MaxApplication
import com.example.data.model.PendingAction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

data class WhatsAppMessageEvent(
    val sender: String,
    val message: String,
    val timestamp: Long,
    val canReply: Boolean,
    val sbnKey: String,
    val isAutoReplyCandidate: Boolean
)

class WhatsAppNotificationListener : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: WhatsAppNotificationListener? = null
            private set

        val isServiceRunning: Boolean
            get() = instance != null

        private val _incomingMessages = MutableSharedFlow<WhatsAppMessageEvent>(extraBufferCapacity = 20)
        val incomingMessages = _incomingMessages.asSharedFlow()

        // Stores recent reply actions by sbn key
        val replyActions = mutableMapOf<String, Notification.Action>()
    }

    private val scope = CoroutineScope(Dispatchers.IO)

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        Log.d("WhatsAppListener", "WhatsApp Notification Listener connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance == this) {
            instance = null
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        if (sbn == null) return
        val packageName = sbn.packageName ?: return

        if (packageName == "com.whatsapp" || packageName == "com.whatsapp.w4b") {
            val notification = sbn.notification ?: return
            val extras = notification.extras ?: return

            val title = extras.getString(Notification.EXTRA_TITLE) ?: extras.getString(Notification.EXTRA_CONVERSATION_TITLE) ?: ""
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

            if (title.isBlank() || text.isBlank() || title.contains("WhatsApp") || text.contains("messages")) {
                return
            }

            // Find quick reply action
            var replyAction: Notification.Action? = null
            val actions = notification.actions
            if (actions != null) {
                for (action in actions) {
                    val remoteInputs = action.remoteInputs
                    if (!remoteInputs.isNullOrEmpty()) {
                        replyAction = action
                        replyActions[sbn.key] = action
                        break
                    }
                }
            }

            val app = applicationContext as? MaxApplication
            val security = app?.securityManager
            val isAutoReplyOn = security?.isWhatsAppAutoReplyEnabled == true

            val event = WhatsAppMessageEvent(
                sender = title,
                message = text,
                timestamp = System.currentTimeMillis(),
                canReply = replyAction != null,
                sbnKey = sbn.key,
                isAutoReplyCandidate = isAutoReplyOn
            )
            _incomingMessages.tryEmit(event)

            // Auto-Read aloud if assistant active
            if (security?.isListeningActive == true) {
                val boss = security.userCallName
                val announcement = "$boss, WhatsApp par $title ka message aaya hai: $text"
                app.ttsManager.speak(announcement)
            }

            // Auto-Reply logic
            if (isAutoReplyOn && replyAction != null) {
                scope.launch {
                    handleAutoReply(title, text, sbn.key, replyAction)
                }
            }
        }
    }

    private suspend fun handleAutoReply(
        sender: String,
        message: String,
        key: String,
        action: Notification.Action
    ) {
        val app = applicationContext as? MaxApplication ?: return
        val security = app.securityManager
        val apiKey = security.geminiApiKey
        if (apiKey.isBlank()) return

        val tone = security.autoReplyTone
        val draftResult = app.geminiService.draftWhatsAppReply(sender, message, tone, apiKey)
        draftResult.onSuccess { draft ->
            if (security.isAutoSendWithoutApproval) {
                sendDirectReply(key, draft)
            } else {
                val boss = security.userCallName
                app.phoneCommander.postPendingConfirmation(
                    PendingAction(
                        actionType = "whatsapp_send",
                        description = "WhatsApp reply to $sender: \"$draft\"",
                        spokenPrompt = "$boss, $sender ko reply bhejna hai: \"$draft\". Bhej doon?",
                        recipient = sender,
                        messageText = draft
                    )
                )
            }
        }
    }

    fun sendDirectReply(sbnKey: String, replyText: String): Boolean {
        val action = replyActions[sbnKey] ?: return false
        val remoteInputs = action.remoteInputs ?: return false
        val remoteInput = remoteInputs.firstOrNull() ?: return false

        val intent = Intent()
        val bundle = Bundle().apply {
            putCharSequence(remoteInput.resultKey, replyText)
        }
        RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, bundle)

        return try {
            action.actionIntent.send(this, 0, intent)
            true
        } catch (e: PendingIntent.CanceledException) {
            Log.e("WhatsAppListener", "Failed to send direct reply", e)
            false
        }
    }
}
