package com.example.service

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.MaxApplication

class AntiTheftDeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.d("DeviceAdmin", "Anti-Theft Device Admin enabled")
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
        Log.w("DeviceAdmin", "Unlock password/PIN failed attempt detected!")
        val app = context.applicationContext as? MaxApplication ?: return
        if (app.securityManager.isAntiTheftArmed && app.securityManager.isWrongPinAlarmEnabled) {
            app.antiTheftController.triggerAlarm("Wrong Lockscreen PIN/Password Attempt")
        }
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        super.onPasswordSucceeded(context, intent)
        Log.d("DeviceAdmin", "Unlock password succeeded")
    }
}
